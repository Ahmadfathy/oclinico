import { Routes } from '@angular/router';
import { FullComponent } from './layouts/full/full.component';
import { BlankComponent } from './layouts/blank/blank.component';

import { AddwardsComponent } from './addwards/addwards.component';
//  import { PaymentComponent } from './payment/payment.component';
import { RadiologyComponent } from './radiology/radiology.component';
import { ViewradiologyComponent } from './viewradiology/viewradiology.component';
import { ViewWardsComponent } from './view-wards/view-wards.component';
import { ViewLaboratoryComponent } from './view-laboratory/view-laboratory.component';

import { PharmacyComponent } from './pharmacy/pharmacy.component';
import {AuthGuard } from './shared/guard/auth.guard';

export const Approutes: Routes = [
  {
    path: '',
    component: FullComponent,
    children: [
      { path: '', redirectTo: '/login', pathMatch: 'full' },
      { path: 'dashboard', loadChildren: './newdashboard/newdashboard.module#newdashboardModule', canActivate: [AuthGuard] },
      // { path: 'dashboard', loadChildren: './dashboards/dashboard.module#DashboardModule' },
      { path: 'clinicinfo', loadChildren: './clinicinfo/clinicinfo.module#ClinicModule', canActivate: [AuthGuard] },
      { path: '', loadChildren: './iuma-appointments/iuma-appointments.module#IumaAppointmentsModule', canActivate: [AuthGuard] },
      { path: 'Communication', loadChildren: './communications/communications.module#MainCommunicationModule', canActivate: [AuthGuard] },
      { path: 'AddCommunication', loadChildren: './addcommunications/addcommunications.module#AddCommunicationModule', canActivate: [AuthGuard] },
      { path: 'Laboratary', loadChildren: './laboratary/laboratary.module#LaborataryModule', canActivate: [AuthGuard] },

      // -----------------wards--------------
      { path: 'wards', loadChildren: './wards/wards.module#WardsModule', canActivate: [AuthGuard] },
      { path: 'addwards', loadChildren: './addwards/addwards.module#AddwardsModule', canActivate: [AuthGuard] },
      { path: 'editwards', loadChildren: './editwards/editwards.module#EditwardsModule', canActivate: [AuthGuard] },


      { path: 'radiology', loadChildren: './radiology/radiology.module#radiologyModule', canActivate: [AuthGuard] },
      { path: 'viewradiology', loadChildren: './viewradiology/viewradiology.module#viewradiologyModule', canActivate: [AuthGuard] },
      { path: 'view-wards', loadChildren: './view-wards/view-wards.module#viewwardsModule', canActivate: [AuthGuard] },
      { path: 'viewLaboratary', loadChildren: './view-laboratory/view-laboratory.module#viewlaboratoryModule', canActivate: [AuthGuard] },

      // -------------------Invoices ------------------------
      { path: 'Maininvoice', loadChildren: './invoices/invoices.module#InvoicesModule', canActivate: [AuthGuard] },
      { path: 'addinvoice', loadChildren: './invoices/addinvoice/addinvoice.module#AddinvoiceModule', canActivate: [AuthGuard] },
      { path: 'viewinvoice', loadChildren: './invoices/viewinvoice/viewinvoice.module#ViewinvoiceModule', canActivate: [AuthGuard] },

      // LAZY LOAD PENDING ..
      //   {   path:'Maininvoice',    

      //   loadChildren: () => import('./invoices/invoices.module').then(mod => mod.InvoicesModule)
      // },



      // ----------------------Products---------------------

      { path: 'product', loadChildren: './products/products.module#ProductsModule', canActivate: [AuthGuard] },
      {
        path: 'addproduct',
        loadChildren: './products/add-product/add-product.module#AddProductModule', canActivate: [AuthGuard]
      },
      {
        path: 'editproduct',
        loadChildren: './products/edit-product/edit-product.module#EditProductModule', canActivate: [AuthGuard]
      },
      {
        path: 'viewproduct',
        loadChildren: './products/view-product/view-product.module#ViewProductModule', canActivate: [AuthGuard]
      },
      {
        path: 'stockadjustment',
        loadChildren: './products/stockadjustment/stockadjustment.module#StockadjustmentModule', canActivate: [AuthGuard]
      },
      {
        path: 'advancesearch',
        loadChildren: './products/advancesearch/advancesearch.module#AdvancesearchModule', canActivate: [AuthGuard]
      },


      // ------------------Expnses-----------------
      { path: 'expenses', loadChildren: './expenses/expenses.module#ExpensesModule', canActivate: [AuthGuard] },

      {
        path: 'addexpense',
        loadChildren: './expenses/addexpense/addexpense.module#AddExpenseModule', canActivate: [AuthGuard]
      },

      {
        path: 'editexpense/:id',
        loadChildren: './expenses/addexpense/addexpense.module#AddExpenseModule', canActivate: [AuthGuard]
      },
      { path: 'viewexpenses', loadChildren: './expenses/viewexpenses/viewexpenses.module#ViewexpensesModule', canActivate: [AuthGuard] },

      // --------------------------Reports----------------

      { path: 'reports', loadChildren: './reports/reports.module#ReportsModule', canActivate: [AuthGuard] },
      {
        path: 'appointmentschedule',
        loadChildren: './reports/appointmentschedule/appointmentschedule.module#AppointmentscheduleModule', canActivate: [AuthGuard]
      },
      {
        path: 'upcomingbirthdays',
        loadChildren: './reports/upcomingbirthdays/upcomingbirthdays.module#UpcomingbirthdaysModule', canActivate: [AuthGuard]
      },
      {
        path: 'dailypayments',
        loadChildren: './reports/dailypayments/dailypayments.module#DailypaymentsModule', canActivate: [AuthGuard]
      },
      {
        path: 'paymentsummary',
        loadChildren: './reports/paymentsummary/paymentsummary.module#PaymentsummaryModule', canActivate: [AuthGuard]
      },
      {
        path: 'balance',
        loadChildren: './reports/balance/balance.module#BalanceModule', canActivate: [AuthGuard]
      },
      {
        path: 'cashreport',
        loadChildren: './reports/cashreport/cashreport.module#CashreportModule', canActivate: [AuthGuard]
      },
      {
        path: 'doctors',
        loadChildren: './reports/doctors/doctors.module#DoctorsModule', canActivate: [AuthGuard]
      },
      {
        path: 'expiryproducts',
        loadChildren: './reports/expiryproducts/expiryproducts.module#ExpiryproductsModule', canActivate: [AuthGuard]
      },
      {
        path: 'outstandinginvoices',
        loadChildren: './reports/outstandinginvoices/outstandinginvoices.module#OutstandinginvoicesModule', canActivate: [AuthGuard]
      },
      {
        path: 'patients',
        loadChildren: './reports/patients/patients.module#PatientsModule', canActivate: [AuthGuard]
      },
      {
        path: 'pricewiseproduct',
        loadChildren: './reports/pricewiseproduct/pricewiseproduct.module#PricewiseproductModule', canActivate: [AuthGuard]
      },
      {
        path: 'practicerevenue',
        loadChildren: './reports/practicerevenue/practicerevenue.module#PracticerevenueModule', canActivate: [AuthGuard]
      },
      {
        path: 'productwisereports',
        loadChildren: './reports/productwisereports/productwisereports.module#ProductwisereportsModule', canActivate: [AuthGuard]
      },
      {
        path: 'referralsources',
        loadChildren: './reports/referralsources/referralsources.module#ReferralsourcesModule', canActivate: [AuthGuard]
      },
      {
        path: 'rptexpenses',
        loadChildren: './reports/rptexpenses/rptexpenses.module#RptexpensesModule', canActivate: [AuthGuard]
      },
      {
        path: 'supplierwiseproducts',
        loadChildren: './reports/supplierwiseproducts/supplierwiseproducts.module#SupplierwiseproductsModule', canActivate: [AuthGuard]
      },

      // ----------------------------GetpaymentModule--------------


      { path: 'getpayment', loadChildren: './payment/payment.module#GetpaymentModule', canActivate: [AuthGuard] },
      {
        path: 'edit-payments',
        loadChildren: './payment/edit-payments/edit-payments.module#EditPaymentsModule', canActivate: [AuthGuard]
      },
      {
        path: 'view-payments',
        loadChildren: './payment/view-payments/view-payments.module#ViewPaymentsModule', canActivate: [AuthGuard]
      },
      {
        path: 'AddPayment',
        loadChildren: './payment/addpayment/addpayment.module#AddpaymentModule', canActivate: [AuthGuard]
      },

      // --------------------------Settings----------------------
      { path: 'settings', loadChildren: './settings/settings.module#SettingsModule', canActivate: [AuthGuard] },

      {
        path: 'AddReferal',
        loadChildren: './settings/addreferal/addreferal.module#AddreferalModule', canActivate: [AuthGuard]
        // component: AddreferalComponent
      },
      {
        path: 'AddReferralDiscount',
        loadChildren: './settings/addrefdiscountsettings/addrefdiscountsettings.module#AddrefdiscountsettingsModule', canActivate: [AuthGuard]
        // component: AddrefdiscountsettingsComponent
      },
      {
        path: "ReferralMasterDetails",
        loadChildren: './settings/addreferalbind/addreferalbind.module#AddreferalbindModule', canActivate: [AuthGuard]
        // component : AddreferalbindComponent
      },
      {
        path: "Addtreatment",
        loadChildren: './settings/add-treatment/add-treatment.module#AddTreatmentModule', canActivate: [AuthGuard]
        //component : AddTreatmentComponent
      },
      {
        path: 'Addtax',
        loadChildren: './settings/add-taxes/add-taxes.module#AddTaxesModule', canActivate: [AuthGuard]
        // component : AddTaxesComponent
      },
      {
        path: 'AddSMSpackage',
        loadChildren: './settings/addsmspackages/addsmspackages.module#AddsmspackagesModule', canActivate: [AuthGuard]
        // component: AddsmspackagesComponent
      },
      {
        path: 'bankdetails',
        loadChildren: './settings/bankmasterdetails/bankmasterdetails.module#BankmasterdetailsModule', canActivate: [AuthGuard]
        // component: BankmasterdetailsComponent
      },
      {
        path: 'bankbranchdetails',
        loadChildren: './settings/bankbranchmasterdetails/bankbranchmasterdetails.module#BankbranchmasterdetailsModule', canActivate: [AuthGuard]
        //component: BankbranchmasterdetailsComponent
      },
      {
        path: 'addslotdetails',
        loadChildren: './settings/addslotdetails/addslotdetails.module#AddslotdetailsModule', canActivate: [AuthGuard]
        // component: AddslotdetailsComponent
      },
      {
        path: 'anotherbranch',
        loadChildren: './settings/anotherbranch/anotherbranch.module#AnotherbranchModule', canActivate: [AuthGuard]
        // component: AnotherbranchComponent
      },

      // ------------gouse-------
      {
        path: 'addbankmaster',
        // component: AddbankmasterComponent
        loadChildren: './settings/addbankmaster/addbankmaster.module#AddbankmasterModule', canActivate: [AuthGuard]
      },
      {
        path: 'addbankbranchmaster',
        loadChildren: './settings/addbankbranchmaster/addbankbranchmaster.module#AddbankbranchmasterModule', canActivate: [AuthGuard]
        // component: AddbankbranchmasterComponent//AddbankbranchmasterModule
      },
      {
        path: 'AddCashReceipt',
        // component: AddcashreceiptsettingsComponent
        loadChildren: './settings/addcashreceiptsettings/addcashreceiptsettings.module#AddcashreceiptsettingsModule', canActivate: [AuthGuard]
      },
      {
        path: 'addclinicinformation',
        // component: AddclinicinformationComponent
        loadChildren: './settings/addclinicinformation/addclinicinformation.module#AddclinicinformationModule'
      },
      {
        path: 'AddDocumentType',
        //component: AdddocumenttypesettingsComponent
        loadChildren: './settings/adddocumenttypesettings/adddocumenttypesettings.module#AdddocumenttypesettingsModule'
      },
      {
        path: 'AddFollowUps',
        //component: AddfollowupssettingsComponent
        loadChildren: './settings/addfollowupssettings/addfollowupssettings.module#AddfollowupssettingsModule'
      },
      {
        path: 'AddInsuranCoverage',
        // component: AddinsucoversettingsComponent
        loadChildren: './settings/addinsucoversettings/addinsucoversettings.module#AddinsucoversettingsModule'
      },
      {
        path: 'AddInsurance',
        //component: AddinsurancesettingsComponent
        loadChildren: './settings/addinsurancesettings/addinsurancesettings.module#AddinsurancesettingsModule'
      },
      {
        path: 'AddOccupations',
        //component: AddoccupationssettingsComponent
        loadChildren: './settings/addoccupationssettings/addoccupationssettings.module#AddoccupationssettingsModule'
      },
      {
        path: "Edit_doctor_treatment",
        // component: EditDoctTreatmentComponent
        loadChildren: "./settings/edit-doct-treatment/edit-doct-treatment.module#EditDoctTreatmentModule"
      },
      {
        path: 'Edittax',
        //component : EditTaxesComponent
        loadChildren: "./settings/edit-taxes/edit-taxes.module#EditTaxesModule"
      },
      {
        path: 'Edittreatment',
        loadChildren: "./settings/edit-treatment/edit-treatment.module#EditTreatmentModule"
      },
      {
        path: 'editbankbranchmaster',
        //component: EditbankbranchmasterComponent
        loadChildren: "./settings/editbankbranchmaster/editbankbranchmaster.module#EditbankbranchmasterModule"
      },

      {
        path: 'editbankmaster',
        // component: EditbankmasterComponent
        loadChildren: "./settings/editbankmaster/editbankmaster.module#EditbankmasterModule"
      },
      {
        path: 'EditDocumentType',
        // component: EditdocumenttypesettingsComponent..
        loadChildren: "./settings/editdocumenttypesettings/editdocumenttypesettings.module#EditdocumenttypesettingsModule"
      },
      {
        path: 'editbranch',
        // component: EditbranchComponent
        loadChildren: "./settings/editbranch/editbranch.module#EditbranchModule"
      },
      {
        path: 'editgeneralsettings',
        //component: EditgeneralsettingsComponent
        loadChildren: "./settings/editdocumenttypesettings/editdocumenttypesettings.module#EditdocumenttypesettingsModule"
      },
      {
        path: 'editInsuranCoverage',
        //component: EditinsucoversettingsComponent

        loadChildren: "./settings/editinsucoversettings/editinsucoversettings.module#EditinsucoversettingsModule"
      },
      {
        path: 'EditInsurance',
        // component: EditinsurancesettingsComponent   
        loadChildren: "./settings/editinsucoversettings/editinsucoversettings.module#EditinsucoversettingsModule"
      },
      {
        path: 'EditNumberSettings',
        //component: EditnumbersettingsComponent
        loadChildren: "./settings/editinsucoversettings/editinsucoversettings.module#EditinsucoversettingsModule"
      },
      {
        path: 'EditOccupations',
        //component: EditoccupationssettingsComponent
        loadChildren: "./settings/editoccupationssettings/editoccupationssettings.module#EditoccupationssettingsModule"
      },
      {
        path: 'EditReferralDiscount',
        //component: EditrefdiscountsettingsComponent
        loadChildren: "./settings/editrefdiscountsettings/editrefdiscountsettings.module#EditrefdiscountsettingsModule"
      },
      {
        path: 'EditReferal',
        //component: EditreferralsettingsComponent
        loadChildren: "./settings/editreferralsettings/editreferralsettings.module#EditreferralsettingsModule"
      },
      {
        path: 'editslotdetails',
        // component: EditslotdetailsComponent
        loadChildren: "./settings/editslotdetails/editslotdetails.module#EditslotdetailsModule"
      },
      {
        path: "MachineDetails",
        loadChildren: "./settings/machine-details/machine-details.module#MachineDetailsModule"
      },
      {
        path: "Add_MachineDetails",
        //component: MachineDetailsAddComponent
        loadChildren: "./settings/machine-details-add/machine-details-add.module#MachineDetailsAddModule"
      },
      {
        path: "Edit_MachineDetails",
        // component: MachineDetailsEditComponent
        loadChildren: "./settings/machine-details-edit/machine-details-edit.module#MachineDetailsEditModule"
      },
      {
        path: "Import_MachineDetails",
        /// component: MachineDetailsImportComponent
        loadChildren: "./settings/machine-details-import/machine-details-import.module#MachineDetailsImportModule"
      },
      {
        path: 'AddClinicAddress',
        //component: MAddarabicadresssettingsComponent
        loadChildren: "./settings/m-addarabicadresssettings/m-addarabicadresssettings.module#MAddarabicadresssettingsModule"
      },
      {
        path: 'addDepartments',
        // component: MAdddepartmentsettingsComponent
        loadChildren: "./settings/m-adddepartmentsettings/m-adddepartmentsettings.module#MAdddepartmentsettingsModule"
      },
      {
        path: 'AddServiceMaster',
        //mponent: MAddservicemastersettingsComponent
        loadChildren: "./settings/m-addservicemastersettings/m-addservicemastersettings.module#MAddservicemastersettingsModule"
      },
      {
        path: 'ClinicAddressDetails',
        // component: MArabicaddrdetailsComponent
        loadChildren: "./settings/m-arabicaddrdetails/m-arabicaddrdetails.module#MArabicaddrdetailsModule"
      },
      {
        path: 'DepartmentsDetails',
        ///component: MDepartmemtdetailssettingsComponent
        loadChildren: "./settings/m-departmemtdetailssettings/m-departmemtdetailssettings.module#MDepartmemtdetailssettingsModule"
      },
      {
        path: 'Specialization',
        //component:MDepartmentspecificationsComponent
        loadChildren: "./settings/m-departmentspecifications/m-departmentspecifications.module#MDepartmemtdetailssettingsModule"
      },
      {
        path: 'AddSpecialization',
        //component:MDeptaddspecificationComponent
        loadChildren: "./settings/m-deptaddspecification/m-deptaddspecification.module#MDeptaddspecificationModule"
      },

      //  --------------------santhoshi-----------------
      {
        path: 'MainTemplate',
        loadChildren: './settings/settings-letter-template/settings-letter-template.module#SettingsLetterTemplateModule'
      },
      {
        path: 'EditTemplate',
        loadChildren: './settings/settings-letter-template-edit/settings-letter-template-edit.module#SettingsLetterTemplateEditModule'
      },
      {
        path: 'ViewTemplate',
        loadChildren: './settings/settings-letter-template-view/settings-letter-template-view.module#SettingsLetterTemplateViewModule'
      },
      {
        path: 'MainLaboratory',
        loadChildren: './settings/settings-laboratory-details/settings-laboratory-details.module#SettingsLaboratoryDetailsModule'
      },
      {
        path: 'EditLaboratory',
        loadChildren: './settings/settings-laboratory-edit-details/settings-laboratory-edit-details.module#SettingsLaboratoryEditDetailsModule'
      },
      {
        path: 'Taxes',
        loadChildren: './settings/taxes/taxes.module#TaxesModule'
      },
      {
        path: "Treatment",
        loadChildren: './settings/treatment/treatment.module#TreatmentModule'
      },
      {
        path: "Treat_MachineDetails",
        loadChildren: './settings/treatment-machine-details/treatment-machine-details.module#TreatmentMachineDetailsModule'
      },
      {
        path: "Edit_Treat_MachineDetails",
        loadChildren: './settings/treatment-machine-details-edit/treatment-machine-details-edit.module#TreatmentMachineDetailsEditModule'
      },
      {
        path: "Add_Treat_MachineDetails",
        loadChildren: './settings/treatment-machine-details-add/treatment-machine-details-add.module#TreatmentMachineDetailsAddModule'
      },
      {
        path: 'AddReferralDiscount',
        // component: AddrefdiscountsettingsComponent
        loadChildren: "./settings/addrefdiscountsettings/addrefdiscountsettings.module#AddrefdiscountsettingsModule"
      },
      {
        path: 'SMSpackages',
        loadChildren: './settings/smspackagesdetails/smspackagesdetails.module#SmspackagesdetailsModule'
      },
      // {
      //   path: 'Communication',
      //   loadChildren: '../communications/communications.module#MainCommunicationModule'
      // },
      {
        path: 'addbankbranchmaster',
        loadChildren: './settings/addbankbranchmaster/addbankbranchmaster.module#AddbankbranchmasterModule'
      },
      {
        path: 'slotdetails',
        loadChildren: './settings/slotdetails/slotdetails.module#SlotdetailsModule'
      },
      {
        path: 'viewbranch',
        loadChildren: './settings/viewbranch/viewbranch.module#ViewbranchModule'
        },

      {
        path: 'AddLaboratory',
        loadChildren: './settings/settings-laboratory-add-details/settings-laboratory-add-details.module#SettingsLaboratoryAddDetailsModule'
      },

      {
        path: 'Referaldiscountdis',
        loadChildren: './settings/referaldiscount/referaldiscount.module#ReferaldiscountModule'
      },
      {
        path: 'Referaldiscounts',
        loadChildren: './settings/refdisountdetailssettings/refdisountdetailssettings.module#RefdisountdetailssettingsModule'
      },

      {
        path: 'Occupations',
        loadChildren: './settings/occupationsdetailssettings/occupationsdetailssettings.module#OccupationsdetailssettingsModule'
      },
      {
        path: 'NumberSettings',
        loadChildren: './settings/numbersettingsdetails/numbersettingsdetails.module#NumbersettingsdetailsModule'
      },

      {
        path: 'EditServiceMaster',
        loadChildren: './settings/m-servicedetailssettings/m-servicedetailssettings.module#MServicedetailssettingsModule'
      },
      {
        path: 'ServiceMasterDetails',
        loadChildren: './settings/m-editservicemastersettings/m-editservicemastersettings.module#MEditservicemastersettingsModule'
      },

 {
        path: 'editDepartments',
        loadChildren: './settings/m-editdepartmentsettings/m-editdepartmentsettings.module#MEditdepartmentsettingsModule'
      },

      {
        path: 'EditClinicAddress',
        loadChildren: './settings/m-editarabicadresssettings/m-editarabicadresssettings.module#MEditarabicadresssettingsModule'
      },

      {
        path:'EditinsuranceType',
        loadChildren: './settings/insuranc-type-edit/insuranc-type-edit.module#InsurancTypeEditModule'
      },

 {
        path: 'MainLaboratoryXray',
        loadChildren: './settings/laboratory-xray-details/laboratory-xray-details.module#LaboratoryXrayDetailsModule'
      },
      {
        path: 'AddLaboratoryXray',
        loadChildren: './settings/laboratory-xray-add-details/laboratory-xray-add-details.module#LaboratoryXrayAddDetailsModule'
      },
      {
        path: 'EditLaboratoryXray',
        loadChildren: './settings/laboratory-xray-edit-details/laboratory-xray-edit-details.module#LaboratoryXrayEditDetailsModule'
      },
 

 {
        path:'EditSpecialization',
        loadChildren: './settings/m-depteditspecification/m-depteditspecification.module#MDepteditspecificationModule'
     },
     {
      path: 'FollowUps',
      loadChildren: './settings/followupssettings/followupssettings.module#FollowupssettingsModule'
    },


{
      path: 'InsuranceCategoryDetails',
      loadChildren: './settings/insurancecatsettingsbind/insurancecatsettingsbind.module#InsurancecatsettingsbindModule'
    },

{
      path: 'EditInsuranceCategory',
      loadChildren: './settings/insurancecatsettingsedit/insurancecatsettingsedit.module#InsurancecatsettingseditModule'
   
    },

{
      path:'insuranceType',
      loadChildren: './settings/insuranc-type/insuranc-type.module#InsurancTypeModule'
    },


{
      path:'AddinsuranceType',
      loadChildren: './settings/insuranc-type-add/insuranc-type-add.module#InsurancTypeAddModule'
    },


    {
      path: 'AddFinanceDetail',
      loadChildren: './settings/fin-add-paymode-details/fin-add-paymode-details.module#FinAddPaymodeDetailsModule'
    },

{
      path: 'MainFinanceDetail',
      loadChildren: './settings/fin-pay-mode-details/fin-pay-mode-details.module#FinPayModeDetailsModule'
    },
    {
      path: 'EditFinanceDetail',
      loadChildren: './settings/fin-edit-paymode-details/fin-edit-paymode-details.module#FinEditPaymodeDetailsModule'
    },

    
{
  path: 'DocumentType',
  loadChildren: './settings/doctypedetailssettings/doctypedetailssettings.module#DoctypedetailssettingsModule'
},
    
{
  path: 'CashReceipts',
  loadChildren: './settings/cashreceiptsettings/cashreceiptsettings.module#CashreceiptsettingsModule'
},
{
  path: 'clinicinformation',
  loadChildren: './settings/clinicinformation/clinicinformation.module#ClinicinformationModule'
},
{
  path: 'Doctorfee',
  loadChildren: './settings/doctor-fee/doctor-fee.module#DoctorFeeModule'
},




{
  path: 'Add_doctorfee',
  loadChildren: './settings/doctor-fee-add/doctor-fee-add.module#DoctorFeeAddModule'
},

{
  path : "Edit_doctorfee",
  loadChildren: './settings/doctor-fee-edit/doctor-fee-edit.module#DoctorFeeEditModule'
},
{
  path: "DoctorTreatment",
  loadChildren: './settings/doctor-treatment/doctor-treatment.module#DoctorTreatmentModule'
},

{
  path : "Add_doctor_treatment",
  loadChildren: './settings/add-doct-treatment/add-doct-treatment.module#AddDoctTreatmentModule'
},
{
  path: 'generalsettings',
   loadChildren: "./settings/generalsettings/generalsettings.module#GeneralsettingsModule"
  },

  {
        path: 'AddInsuranceCategory',
        loadChildren: './settings/insurancecatsettingsadd/insurancecatsettingsadd.module#InsurancecatsettingsaddModule'
      },

      {
            path: 'InsuranceDetails',
            loadChildren: './settings/insdetailsbindsettings/insdetailsbindsettings.module#InsdetailsbindsettingsModule'
          },

          {
                path: 'InsuranCoverageDetails',
                loadChildren: './settings/insucoverdetailssettings/insucoverdetailssettings.module#InsucoverdetailssettingsModule'
              },
      // --------------------------PharmacyComponent------------------
      { path: 'Pharmacy', loadChildren: './pharmacy/pharmacy.module#PharmacyModule', },

      {
        path: 'ViewPharmacy',
        loadChildren: './pharmacy/viewpharmacydetails/viewpharmacydetails.module#ViewpharmacydetailsModule'
      },
      {
        path: 'Addmedication',
        loadChildren: './pharmacy/addmedication/addmedication.module#AddmedicationComponentModule'
      },



      // ------------------------
      // {        path: '',  loadChildren: './usermanagement/usermanagement.module#UsermanagementModule'      },

      {
        path: 'jobtitle',
        loadChildren: './usermanagement/jobtitle/jobtitle.module#JobtitleModule'
      },
      {
        path: 'usercreate',
        loadChildren: './usermanagement/usercreation/usercreation.module#UsercreationModule'
      },
      {
        path: 'manageuser',
        loadChildren: './usermanagement/manageuser/manageuser.module#ManageuserModule'
      },
      {
        path: 'loginactivity',
        loadChildren: './usermanagement/loginactivities/loginactivities.module#LoginactivitiesModule'
      },
      {
        path: 'useradd',
        loadChildren: './usermanagement/useradd/useradd.module#UseraddModule'
      },
      {
        path: 'useredit',
        loadChildren: './usermanagement/useredit/useredit.module#UsereditModule'
      },
      {
        path: 'userview',
        loadChildren: './usermanagement/userview/userview.module#UserviewModule'
      },
      {
        path: 'addjobtitle',
        loadChildren: './usermanagement/addjobtitle/addjobtitle.module#AddjobtitleModule'
      },
      {
        path: 'editjobtitle',
        loadChildren: './usermanagement/editjobtitle/editjobtitle.module#EditjobtitleModule'
      },

      // ---------------Patientinfo-----------------
      // { path: 'Patientinfo', loadChildren: './patientinfo/patientinfo/patientinfo.module#PatientinfoModule' },
      {
        path: 'addpatient',
        loadChildren: './patientinfo/addpatient/addpatient.module#AddpatientModule'
      },


      {
        path: 'editpatient',
        loadChildren: './patientinfo/editpatient/editpatient.module#EditpatientModule'
      },


      {
        path: 'viewpatient',
        loadChildren: './patientinfo/viewpatient/viewpatient.module#ViewpatientModule'
      },


      {
        path: 'billing',
        loadChildren: './patientinfo/billing/billing.module#BillingModule'
      },


      {
        path: 'treatmentnote',
        loadChildren: './patientinfo/treatmentnotes/treatmentnotes.module#TreatmentnotesModule'
      },


      {
        path: 'addtreatment',
        loadChildren: './patientinfo/addtreatment/addtreatment.module#AddtreatmentModule'
      },
      {
        path: 'edittretement',
        loadChildren: './patientinfo/edittretement/edittretement.module#EdittretementModule'
      },

      {
        path: 'addprescription',
        loadChildren: './patientinfo/addprescription/addprescription.module#AddprescriptionModule'
      },


      {
        path: 'addletter',
        loadChildren: './patientinfo/addletter/addletter.module#AddletterModule'
      },



      {
        path: 'addvisitnote',
        loadChildren: './patientinfo/addvisitnote/addvisitnote.module#AddvisitnoteModule'
      },



      {
        path: 'prescription',
        loadChildren: './patientinfo/prescription/prescription.module#PrescriptionModule'
      },



      {
        path: 'autocomplate',
        loadChildren: './patientinfo/autocomplate/autocomplate.module#AutocomplateModule'
      },


      {
         path: 'payments',
      
        loadChildren: './patientinfo/payments/payments.module#PaymentsModule'
      },


      {
        path: 'invoices',
        loadChildren: './patientinfo/patient-details-invoices/patient-details-invoices.module#PatientDetailsInvoicesModule'
      },



      {
        path: 'addatachments',
        loadChildren: './patientinfo/addattachments/addattachments.module#AddattachmentsModule'
      },


      {
        path: 'appoinmentsgrid',
        loadChildren: './patientinfo/appoinmentsgrid/appoinmentsgrid.module#AppoinmentsgridModule'
      },



      {
        path: 'laboratory',
        loadChildren: './patientinfo/laboratory/laboratory.module#LaboratoryModule'
      },



      {
        path: 'visitnote',
        loadChildren: './patientinfo/visitnote/visitnote.module#VisitnoteModule'
      },



      {
        path: 'letters',
        loadChildren: './patientinfo/letters/letters.module#LettersModule'
      },


      {
        path: 'viewprescription',
        loadChildren: './patientinfo/viewprescription/viewprescription.module#ViewprescriptionModule'
      },



      {
        path: 'attachements',
        loadChildren: './patientinfo/attachments/attachments.module#AttachmentsModule'
      },


      {
        path: 'editattachments',
        loadChildren: './patientinfo/editattachments/editattachments.module#EditattachmentsModule'
      },


      {
        path: 'viewattachments',
        loadChildren: './patientinfo/viewattachment/viewattachment.module#ViewattachmentModule'
      },



      {
        path: 'editletters',
        loadChildren: './patientinfo/editletters/editletters.module#EditlettersModule'
      },


      {
        path: 'viewletters',
        loadChildren: './patientinfo/viewletters/viewletters.module#ViewlettersModule'
      },


      {
        path: 'editvisitnote',
        loadChildren: './patientinfo/editvisitnote/editvisitnote.module#EditvisitnoteModule'
      },



      {
        path: 'viewvisitnote',
        loadChildren: './patientinfo/viewvisitnote/viewvisitnote.module#ViewvisitnoteModule'
      },


      {
        path: 'xray',
        loadChildren: './patientinfo/xray/xray.module#XrayModule'
      },


      {
        path: 'procedure',
        loadChildren: './patientinfo/procedure/procedure.module#ProcedureModule'
      },

      {
        path: 'admission',
        loadChildren: './patientinfo/admissondetailes/admissondetailes.module#AdmissondetailesModule'
      },


      {
        path: 'discharge',
        loadChildren: './patientinfo/dischargedetailes/dischargedetailes.module#DischargedetailesModule'
      },


      {
        path: 'communications',
        loadChildren: './patientinfo/patient-details-communications/patient-details-communications.module#PatientDetailsCommunicationsModule'
      },


      {
        path: 'Addfamilydetails',
        loadChildren: './patientinfo/addfamilydetails/addfamilydetails.module#AddfamilydetailsModule'
      },
      {
        path: 'Editfamilydetails',
        loadChildren: './patientinfo/editfamilydetails/editfamilydetails.module#EditfamilydetailsModule'
      },


      // ---------------------

      // {        path: '',  loadChildren: './er/er.module#ErModule'},

      { path: 'eraddpatient', loadChildren: './er/eraddpatient/eraddpatient.module#EraddpatientModule' },
      { path: 'ereditpatient', loadChildren: './er/ereditpatient/ereditpatient.module#EreditpatientModule' },
      { path: 'erpatientinfo', loadChildren: './er/erpatientinfo/erpatientinfo.module#ErpatientinfoModule' },
      { path: 'erviewpatient', loadChildren: './er/erviewpatient/erviewpatient.module#ErviewpatientModule' },



      // ----------------------day surgery---------------
      // {        path: '',  loadChildren: './daysurgery/daysurgery.module#DaysurgeryModule'},
      { path: 'dayaddpatient', loadChildren: './daysurgery/eraddpatient/eraddpatient.module#EraddpatientModule' },
      { path: 'dayeditpatient', loadChildren: './daysurgery/ereditpatient/ereditpatient.module#EreditpatientModule' },
      { path: 'daypatientinfo', loadChildren: './daysurgery/erpatientinfo/erpatientinfo.module#ErpatientinfoModule' },
      { path: 'dayviewpatient', loadChildren: './daysurgery/erviewpatient/erviewpatient.module#ErviewpatientModule' },

      // --------------IUMC  Appointments-------------------
      { path: 'all', loadChildren: './iuma-appointments/all/all.module#AllModule' },
      { path: 'add', loadChildren: './iuma-appointments/add/add.module#AddModule' },
      { path: 'calendar', loadChildren: './iuma-appointments/calendar/calendar.module#CalendarModule' },
       { path: 'request', loadChildren: './iuma-appointments/request/request.module#RequestModule' },
      { path: 'todays', loadChildren: './iuma-appointments/todays/todays.module#TodaysModule' },
      { path: 'upcoming', loadChildren: './iuma-appointments/upcoming/upcoming.module#UpcomingModule' }
      //UpcomingModule
    ]
  },
  {
    path: '',
    component: BlankComponent,
    children: [
      {
        path: '',
        loadChildren:
          './authentication/authentication.module#AuthenticationModule'
      }
    ]
  },
  {
    path: '**',
    redirectTo: '/404'
  },
];